
// function valid(text) {
//     var pattren = "^[a-zA-Z]$"
//     if(pattren.search == -1){
//         return false;
//     }
//     else{
//         return true;
//     }
// }

function validate(){
    var regName = /^[a-zA-Z]+ [a-zA-Z]+$/;
    var fname = (document.getElementById("fname").value);
    if(!regName.test(fname)){
        alert('Please enter your full name (first & last name).');
        return false;
    }else{
        alert('Valid name given.');
        return true;
    }
}

// function validate() {
  
//     var user = document.getElementById("e").value;
//     var user2 = document.getElementById("e");
//     var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
//     if (re.test(user)) {
//         alert("done");
//         return true;
//     }
//     else {
//         user2.style.border = "red solid 3px";
//         return false;
//     }
// }

// function validateForm() {
//     // console.log(asdf);
//     // preventDefault();
//     if(validate(fname)){
//         console.log("true--");
//     }
//     else{
//         console.log("false--");
//     }
// }