const add=(a,b)=>{
    function show(){
      console.log("hiii");
    }
    show();
    return a+b;
  }
  
  console.log(add(34,56));