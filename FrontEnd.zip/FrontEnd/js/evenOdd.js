
function CountingEvenOdd()
{
    var arr_size = prompt("Enter array size");
    for (let index = 0; index < arr_size; index++) {
        const arr = prompt("Enter numbers");
    }
    let even_count = 0;
	let odd_count = 0;
    
	for (let i = 0; i < arr_size; i++) {
        
        if (arr[i] & 1 == 1)
            odd_count++;
        else
            even_count++;
	}
}
console.log(CountingEvenOdd());
document.querySelector("#result").innerHTML=("Number of even elements = " + even_count
    + "<br>" + "Number of odd elements = " + odd_count);


	


