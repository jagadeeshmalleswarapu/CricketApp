
function valid(num) {
    var pattren = "^[0-9]+$";
    if(num.search(pattren)==-1)
        return false;
    else
        return true;
}

function calout() {
    var res=document.getElementById("result").value;
    var out= document.querySelector("#resultset").value;
    if(out === "add"){
        res = add();
    }
    if(out === "sub"){
        res = sub();
    }
    if(out === "mul"){
        res = mul();
    }
    if(out === "div"){
        res = div();
    }
    
}



function add() {
    var num1= (document.querySelector("#num1").value).trim();
    var num2= (document.querySelector("#num2").value).trim();
    if(num1!=="" && num2!==""){
        if(valid(num1) && valid(num2)){
            var num1=parseInt(num1);
            var num2 = parseInt(num2);
    document.querySelector("#result").value=(num1+num2);
    document.querySelector("#result").style.backgroundColor = "yellow";
    console.log(document.querySelector("#result").value);
    }
    else{
        document.querySelector("#num1").style.borderColor="red"
        document.querySelector("#num2").style.borderColor="red"
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").style.backgroundColor="red";
    
    }
}
    else{
        document.querySelector("#num1").style.borderColor="red";
        document.querySelector("#num2").style.borderColor="red";
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").style.backgroundColor="red";
    }
}

function sub() {
    var num1= (document.querySelector("#num1").value).trim();
    var num2= (document.querySelector("#num2").value).trim();
    if(num1!=="" && num2!==""){
        if(valid(num1) && valid(num2)){
            var num1=parseInt(num1);
            var num2 = parseInt(num2);
    document.querySelector("#result").value=(num1-num2);
    document.querySelector("#result").style.backgroundColor = "yellow";
    console.log(document.querySelector("#result").value);
    }
    else{
        document.querySelector("#num1").style.borderColor="red";
        document.querySelector("#num2").style.borderColor="red";
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").style.backgroundColor="red";
    
    }
}
    else{
        document.querySelector("#num1").style.borderColor="red";
        document.querySelector("#num2").style.borderColor="red";
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").style.backgroundColor="red";
    }
}

function mul() {
    var num1= (document.querySelector("#num1").value).trim();
    var num2= (document.querySelector("#num2").value).trim();
    if(num1!=="" && num2!==""){
        if(valid(num1) && valid(num2)){
            var num1=parseInt(num1);
            var num2 = parseInt(num2);
    document.querySelector("#result").value=(num1*num2);
    document.querySelector("#result").style.backgroundColor = "yellow";
    console.log(document.querySelector("#result").value);
    }
    else{
        document.querySelector("#num1").style.borderColor="red";
        document.querySelector("#num2").style.borderColor="red";
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").backgroundColor="red";
    
    }
}
    else{
        document.querySelector("#num1").style.borderColor="red";
        document.querySelector("#num2").style.borderColor="red";
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").backgroundColor="red";
    }
}

function div() {
    var num1= (document.querySelector("#num1").value).trim();
    var num2= (document.querySelector("#num2").value).trim();
    if(num1!=="" && num2!==""){
        if(valid(num1) && valid(num2)){
            var num1=parseInt(num1);
            var num2 = parseInt(num2);
    document.querySelector("#result").value=(num1/num2);
    document.querySelector("#result").style.backgroundColor = "yellow";
    console.log(document.querySelector("#result").value);
    }
    else{
        document.querySelector("#num1").style.borderColor="red";
        document.querySelector("#num2").style.borderColor="red";
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").backgroundColor="red";
    
    }
}
    else{
        document.querySelector("#num1").style.borderColor="red";
        document.querySelector("#num2").style.borderColor="red";
        document.querySelector("#result").innerText="Please enter correct value";
        document.querySelector("#result").backgroundColor="red";
    }
}