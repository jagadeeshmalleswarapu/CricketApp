// function meetUp(){
//     let allgood = true;
//     let rp = new Promise((resolve,reject)=>{
//         if(allgood){
//             resolve("both arrived at time")
//         }
//         else{
//             reject("sorry, He rejected")
//         }
//     }
//     )
//     return rp;
// } 
// // console.log(meetUp);
// let promise = meetUp();
// promise.then((resp)=>{
//     console.log("meet success")
// })
// .catch(error=>{
//     console.log("error on catch");
// })

function test1(){
    console.log("i am test 1---");
}
function test2(){
    console.log("i am 2nd test <<<<<");
}
async function samp(){
    await test1()
    test2()
}
samp();