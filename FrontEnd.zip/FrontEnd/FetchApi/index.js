

function createDepartment()
{
    let newdept={
        "id": 432,
        "deptName":"manager",
        "location":"hyderabad"
    }

    fetch("http://localhost:3000/dept",{
        method:"post",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify(newdept)
    }).then((data)=>{
        console.log(data,"Inserted");
    })
} 

createDepartment();