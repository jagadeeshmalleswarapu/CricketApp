package com.emids.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emids.entity.NewsSec;

public interface NewsRepository extends JpaRepository<NewsSec, Integer>{

}
