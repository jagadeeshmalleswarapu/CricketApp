package com.emids.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emids.entity.Cards;
import com.emids.exception.PlayerNotFound;
import com.emids.service.CardsService;

@RestController
@RequestMapping("cards")
@CrossOrigin(origins = "http://localhost:3000")
public class CardsController {

	@Autowired
	private CardsService service;
	
	
	@GetMapping("/all")
	public ResponseEntity<List<Cards>> getAll(){
		List<Cards> card = service.findAllCards();
		return new ResponseEntity<List<Cards>>(card,HttpStatus.OK);
	}
	

	@GetMapping("/fav/{id}")
	public ResponseEntity<String> putFavByCardId(@PathVariable("id") long id) throws PlayerNotFound{
		service.getFavAndSave(id);
		return new ResponseEntity<String>("Successfully Liked",HttpStatus.OK);
	}
	
	@GetMapping("/rec/{id}")
	public ResponseEntity<String> putRecByCardId(@PathVariable("id") long id) throws PlayerNotFound{
		service.getRecAndSave(id);
		return new ResponseEntity<String>("Successfully Added to Recommended section",HttpStatus.OK);
	}
	

	@GetMapping("/call/{id}")
	public ResponseEntity<Cards> findByCardId(@PathVariable("id") long id) throws PlayerNotFound{
	
		Cards card = service.findByCardsId(id);
		return new ResponseEntity<Cards>(card,HttpStatus.OK);
	}
	
	@GetMapping("/name/{fullName}")
	public ResponseEntity<Cards> findByFullName(@PathVariable("fullName") String fullName) throws PlayerNotFound{
		Cards cards = service.findByFullName(fullName);
		return new ResponseEntity<Cards>(cards,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
}
