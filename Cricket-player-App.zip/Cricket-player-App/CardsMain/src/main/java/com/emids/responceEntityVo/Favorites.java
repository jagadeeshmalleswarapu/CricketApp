package com.emids.responceEntityVo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Favorites {

private Long id;
	
	private String fullName;
	private String majorTeam;
	private String img;
	private String countryName;
}
