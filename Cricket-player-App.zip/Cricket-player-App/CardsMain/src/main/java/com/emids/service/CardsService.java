package com.emids.service;

import java.util.List;

import com.emids.entity.Cards;
import com.emids.exception.PlayerNotFound;
import com.emids.responceEntityVo.ResponseEntityVo;

public interface CardsService {
	public List<Cards> findAllCards();
	
	public Cards findByCardsId(long id) throws PlayerNotFound;
	
	public ResponseEntityVo getFavAndSave(long id) throws PlayerNotFound;

	public ResponseEntityVo getRecAndSave(long id) throws PlayerNotFound;
	
	public Cards findByFullName(String fullName) throws PlayerNotFound;
}
