package com.emids.exception;

public class FavoritesNotFound extends Exception{
	
	private String message;

	public FavoritesNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FavoritesNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FavoritesNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FavoritesNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FavoritesNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "FavoritesNotFound [message=" + message + "]";
	}
	
}
