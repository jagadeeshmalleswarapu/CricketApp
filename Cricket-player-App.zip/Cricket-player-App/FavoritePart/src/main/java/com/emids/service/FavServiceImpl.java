package com.emids.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emids.entity.Favorites;
import com.emids.exception.FavoritesAlreadyExists;
import com.emids.exception.FavoritesNotFound;
import com.emids.repository.FavRepository;
@Service
public class FavServiceImpl implements FavService{

	
	@Autowired
	private FavRepository repo;
	
	@Override
	public void savFav(Favorites favorites) throws FavoritesAlreadyExists{
		if(repo.existsById(favorites.getId())) {
			throw new FavoritesAlreadyExists();
		}		
		repo.save(favorites);
	}

	@Override
	public List<Favorites> findAllFav(){
		List<Favorites> list = repo.findAll();
		
		return list;
	}

	@Override
	public void deleteByFullName(long id) {
		repo.deleteById(id);
	}

}
