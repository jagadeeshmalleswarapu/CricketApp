package com.emids.service;

import java.util.List;

import com.emids.entity.Favorites;
import com.emids.exception.FavoritesAlreadyExists;
import com.emids.exception.FavoritesNotFound;

public interface FavService {

	public void savFav(Favorites favorites) throws FavoritesAlreadyExists;
	
	public List<Favorites> findAllFav();
	
	public void deleteByFullName(long id) throws FavoritesNotFound;
}
