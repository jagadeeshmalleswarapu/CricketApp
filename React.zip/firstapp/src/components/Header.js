
import React,{Component} from 'react'

class Header extends Component{
    render(){
        return( 
        <div>
            <h5>i am header h5</h5>
        </div>
    )}
}

export default Header