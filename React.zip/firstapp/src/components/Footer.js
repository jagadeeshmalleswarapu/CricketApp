
import React from 'react'

function Footer() {
  return (
    <div>
        <h2>I am from Footer</h2>
    </div>
  )
}

export default Footer