// import { render } from "@testing-library/react";
import { add,sub } from "./Calculator";

it('test method added',()=>{
    const actual = add(23,65)
    const expected = 88
    expect(actual).toBe(expected)
})