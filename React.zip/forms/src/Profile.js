import React from 'react'
import ApiCall from './ApiCall'

function Profile() {
  return (
    <div>
    <h1>Profile</h1>
    <ApiCall/>
    </div>
  )
}

export default Profile