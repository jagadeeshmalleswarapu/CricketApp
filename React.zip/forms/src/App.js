
import './App.css';
import FunctionalForm from './FunctionalForm';
import { BrowserRouter as Router,Link,Route,Routes } from 'react-router-dom';
import Profile from './Profile';
import Contact from './Contact';
import Error from './Error';

function App() {
  return (
    <div className="App">
      {/* <FunctionalForm/> */}
      {/* <ClassForm/> */}


      <Router>
      <Link to="/function">-Function- </Link>
      <Link to="/profile">-profile- </Link>
      <Link to="/contact">-contact- </Link>
      <Routes>

        <Route path='/function' element={<FunctionalForm/>}></Route>
        <Route path='/profile' element={<Profile/>}></Route>
        <Route path='/contact' element={<Contact/>}></Route>
        <Route path='/*' element={<Error/>}></Route>
      </Routes>

      </Router>
    </div>
  );
}

export default App;
