import React, { Component } from "react";
import axios from "axios";

const myApi = axios.create({
  baseURL: `http://localhost:8111`,
});

export class ApiCall extends Component {
  constructor(props) {
    super(props);

    this.state = {
      dep: [],
    };
  }
  getallDept = () => {
    myApi.get("/all").then((dept) => {
      console.log(dept);
      this.setState({
        dep: dept.data,
      });
    });
  };



  render() {
    return (
      <div>
        <ul>
          {this.state.dep.map((d) => (
            <li>{d.id}</li>
          ))}
        </ul>

        <button onClick={this.getallDept}>click</button>

        <div></div>
      </div>
    );
  }
}

export default ApiCall;
