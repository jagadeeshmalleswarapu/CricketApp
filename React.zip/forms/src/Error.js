import React from 'react'

function Error() {
  return (
    <div style='color:red'>404 Error</div>
  )
}

export default Error