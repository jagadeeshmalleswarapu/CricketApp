import React, { useState } from "react";

function FunctionalForm() {
  const [output, input] = useState("");
  const [output1, input1] = useState("");
  const [users, setUser] = useState("");
  const [msg, setMsg] = useState("");
  const [logMsg, setLogMsg] = useState("");

  function userName(event) {
    input(event.target.value);
  }

  function userMessage(event) {
    input1(event.target.value);
  }

  function submitData(event) {
    setUser(output);
    setMsg(output1);
    event.preventDefault();
    if (output === "jagadeesh") {
      setLogMsg("success");
    } else {
      setLogMsg("failed");
    }
  }

  return (
    <div>
      <br />
      <hr />
      {output}
      <hr />
      {output1}
      <hr />
      {users} {msg}
      <form onSubmit={submitData}>
        <input type="text" placeholder="name" onChange={userName} />
        <input type="text" placeholder="message" onChange={userMessage} />
        <button>submit</button>
      </form>
      <h1>{logMsg}</h1>
    </div>
  );
}

export default FunctionalForm;
