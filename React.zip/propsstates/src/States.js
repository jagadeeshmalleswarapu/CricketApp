import React, { Component } from 'react'

export class States extends Component {

    constructor(props){
        super(props)

        this.state={
            name:"i am from states"
        }
    }
  render() {
    return (
      <div>states
      <h4>{this.state.name}</h4>
      </div>
    )
  }
}

export default States