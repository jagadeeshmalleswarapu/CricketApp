import React, { Component } from 'react'



export class ChangeState extends Component {

    constructor(props){
        super(props)
        this.state={
            title:this.props.title,
            message:this.props.message
        }
    }
    updateState(){
        this.setState({
            title:"React",
            message:"I am from constructor in like dislike"
        })
    }
    render() {
    return (
      <div>
      <p>

      LikeDislike
      </p>

      <h2>{this.state.title}</h2>
      <h2>{this.state.message}</h2>
      <button onClick={() => {this.updateState()}}>change</button>
      </div>
    )
  }
}

export default ChangeState