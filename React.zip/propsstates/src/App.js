
import './App.css';
import Article from './Article';
import ChangeState from './ChangeState';
import Classprops from './Classprops';
import LikeDislike from './LikeDislike';
import States from './States';

function App() {
  return (
    <div className="App">
    <h1>Hello Jagadeesh</h1>
    <Article title="Emids Tech" salary={2000}/>
    <Article/>
    <Classprops name="jagadeesh"/>
    <States/>    
    <ChangeState title="comp" message="i am from component likedislike" />
    <LikeDislike/>
    </div>
  );
}

export default App;
