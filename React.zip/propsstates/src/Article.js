import React from 'react'
import PropTypes from 'prop-types'

function Article(props) {
  return (
      <div>
    <div>Article : {props.title}</div>
    <h1>Salary : {props.salary}</h1>
    </div>
  )
}

Article.defaultProps={
    title:"I am from default props"
}

Article.propTypes={
    title: PropTypes.string,
    salary: PropTypes.string
}

export default Article;