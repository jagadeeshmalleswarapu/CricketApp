import React, { Component } from 'react'

export class ClassComponenet extends Component {
  

    constructor(props){
        super(props)
        this.state={
            count:0
        }
        this.Button3 = this.Button3.bind(this)
    }

    buttonClickedEvent(){
        console.log("External function used to handle the clicked - 1 ");
        this.setState({
            count:this.state.count+1
        },
        ()=>{
            console.log(this.state.count);
        }
        )
    }
  
    buttonClicked2(){
        console.log("button 2 clicked");
        this.setState({
            count:this.state.count+1
        },
        ()=>{
            console.log(this.state.count);
        }
        )
    }

    Button3(){
        console.log("button 3");
        this.setState({
            count:this.state.count+1
        },
        ()=>{
            console.log(this.state.count);
        }
        )
    }
 
    render() {
    return (
      <div>{this.state.count}
      <button onClick={this.buttonClickedEvent.bind(this)}>Component-Button1</button>
      <button onClick={()=> {this.buttonClicked2()}}>Component-Button2</button>
      <button onClick={this.Button3}>Component-Button3</button>
      </div>
    )
  }
}

export default ClassComponenet