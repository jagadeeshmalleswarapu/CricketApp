import React,{useState} from 'react'

function FunctionalForm() {
  
    const [comment,setComment] = useState("")
    let min = "";

    function listenComment(event){
        console.log(event.target.value);
        
        setComment(min)
        

    }
  
    
    return (
    <div>
    {comment}
    <hr/>
    <br/>
    <input onChange={listenComment} type="text" placeholder='input comment'/><br/>
    <button onClick={listenComment}>Post</button>


    </div>
  )
}

export default FunctionalForm