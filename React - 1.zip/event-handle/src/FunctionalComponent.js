import React from 'react'

function FunctionalComponent() {
    function buttonClickedEvent(){
        console.log("External function used to handle the clicked");
    }
  return (
      <div>

        <button onClick={ function (){ console.log("button clicked"); alert("you clicked button") } }>In-Button</button>
        <button onClick={buttonClickedEvent}>External-Button</button>

      </div>
  )
}

export default FunctionalComponent