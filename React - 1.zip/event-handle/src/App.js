
import './App.css';
import ClassComponenet from './ClassComponenet';
import FunctionalComponent from './FunctionalComponent';
import FunctionalForm from './FunctionalForm';

function App() {
  return (
    <div className="App">
    {/* <FunctionalComponent/> */}
    {/* <ClassComponenet/> */}
    <FunctionalForm/>
    </div>
  );
}

export default App;
